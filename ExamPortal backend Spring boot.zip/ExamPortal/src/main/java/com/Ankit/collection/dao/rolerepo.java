package com.Ankit.collection.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Ankit.collection.model.role;

public interface rolerepo  extends JpaRepository<role, Long>{

}
