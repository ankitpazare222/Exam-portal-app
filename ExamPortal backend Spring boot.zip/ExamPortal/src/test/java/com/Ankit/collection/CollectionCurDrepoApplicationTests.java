package com.Ankit.collection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollectionCurDrepoApplicationTests {

	@Test
	void contextLoads() {
	}

}
